interface EngineBehaviour {
    public String start(Mobil mobil);
    public int gas(int persenFuel);
    public String stop(Mobil mobil);
}

