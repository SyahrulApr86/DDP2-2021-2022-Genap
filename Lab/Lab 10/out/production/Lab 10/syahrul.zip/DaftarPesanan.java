import java.util.ArrayList;
import java.util.Collections;

public class DaftarPesanan<T extends Pesanan> {
    //attributes
    private ArrayList<T> pesanans;
    private T pesananSekarang;

    public DaftarPesanan() {
        //Constructor
        pesanans = new ArrayList<>();
    }

    public void tambahPesanan(T pesanan) {
        // menambahkan pesanan ke dalam daftar pesanan
        this.pesanans.add(pesanan);
    }

    public T nextPesanan() {
        // jika pesanan sekarang tidak ada, maka pesanan sekarang adalah pesanan pertama
        if (pesananSekarang == null) {
            pesananSekarang = pesanans.get(0);
        }
        else { // jika pesanan sekarang ada, maka pesanan sekarang adalah pesanan selanjutnya
            int index = pesanans.indexOf(pesananSekarang);
            if (index < pesanans.size() - 1) {
                pesananSekarang = pesanans.get(index + 1);
            }
            else { // jika pesanan sekarang adalah pesanan terakhir, maka pesanan sekarang tidak ada
                pesananSekarang = null;
            }
        }
        return pesananSekarang;
    }

    public void urutkan() {
        // mengurutkan pesanan berdasarkan prioritas
        Collections.sort(pesanans);
    }

}
